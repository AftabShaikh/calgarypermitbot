import{bT as o}from"./vendor-CdN8G32S.js";function e(){return o.jsx("h1",{children:"404"})}e.displayName="NoPage";export{e as Component};
//# sourceMappingURL=NoPage-Dk69JQke.js.map
